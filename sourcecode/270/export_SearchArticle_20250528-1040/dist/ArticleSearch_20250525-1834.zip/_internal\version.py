__version__ = "2.5.0"  # Pas dit manueel aan bij elke release
